<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="Logo.png">
    <title>Zion Colors | Book Now</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Abril+Fatface|Poppins">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Spectral|Rubik">
    <style>
        body {
            font-family: Poppins, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #FDFD96, #F8C8DC);
        }
        header {
            background: linear-gradient(to right, #ff66a3, #CF9FFF);
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            font-family: 'Abril Fatface', serif;
            margin: 0;
            color: #fff;
            font-size: 40px;
            letter-spacing: 2px;
        }
        nav {
            background-color: #ff66a3;
            padding: 10px 0;
            text-align: center;
        }
        nav ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }
        nav ul li {
            display: inline;
            margin: 0 10px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
        }
        nav ul li a.active {
            background-color: #fff;
            color: #ff66a3;
            border-radius: 15px;
            padding: 5px;
        }
        footer {
            background: linear-gradient(to right, #ff66a3, #CF9FFF);
            padding: 20px 0;
            text-align: center;
            color: #fff;
        }
        .label-container {
            text-align: center;
        }
        .label {
            font-size: 1.5em;
            margin-bottom: 10px;
        }
        .container-booking {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            overflow-y: auto;
        }
        h1 {
            text-align: center;
        }
        h2 {
            max-width: 900px;
            font-family: Spectral, serif;
            font-size: 40px;
            color: #ff66a3;
        }
        table {
            table-layout: fixed;
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            width: 14.28%; /* 100% divided by 7 days */
            height: 40px;  /* Adjust height as needed */
            border: 1px solid black;
            text-align: center;
            padding: 10px;
            box-sizing: border-box; /* Ensures padding does not affect the width/height */
        }
        th {
            background-color: #f0f0f0;
        }
        td {
            vertical-align: middle; /* Centers the text vertically */
        }
        .button-container {
            text-align: center;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        button {
            background-color: #87ceeb;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 25px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #005F6B;
        }
        .time-slots {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .time-slot {
            margin: 5px;
        }
        .disabled {
            pointer-events: none;
            color: #aaa;
        }
        .selected-cell {
            background-color: #87ceeb;
            color: white;
        }
        .error-message {
            color: red;
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container-booking">
        <h2><center>Reservation: Date and Time</center></h2><br>
        <div class="button-container">
            <button id="prevButton">&#8249; Prev Month</button>
            <button id="nextButton">Next Month &#8250;</button>
        </div>
        <div class="label-container">
            <span class="label" id="monthLabel"></span>
        </div>
        <table id="calendar">
            <thead>
                <tr>
                    <th>Sun</th>
                    <th>Mon</th>
                    <th>Tue</th>
                    <th>Wed</th>
                    <th>Thu</th>
                    <th>Fri</th>
                    <th>Sat</th>
                </tr>
            </thead>
            <tbody>
                <!-- Calendar rows will be dynamically added here -->
            </tbody>
        </table>
        <div id="timeSlots"></div>
    </div>
    <footer>
        <p>&copy; 2024 Zion Colors. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
    const calendar = document.getElementById("calendar");
    const prevButton = document.getElementById("prevButton");
    const nextButton = document.getElementById("nextButton");
    const monthLabel = document.getElementById("monthLabel");
    const timeSlotsContainer = document.getElementById("timeSlots");
    let currentMonth = 4; // April is month 3 (0-indexed)
    let currentYear = 2024;
    let selectedDate = null;
    let selectedDateCell = null;
    let selectedSlot = null;

    function updateCalendar() {
        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        const firstDay = new Date(currentYear, currentMonth, 1).getDay();
        const today = new Date();
        let dayCounter = 1;
        let tbody = calendar.querySelector('tbody');
        tbody.innerHTML = "";

        monthLabel.textContent = `${months[currentMonth]} ${currentYear}`;

        // Create rows only as needed
        for (let row = 0; row < 6 && dayCounter <= daysInMonth; row++) {
            let tableRow = tbody.insertRow();
            for (let col = 0; col < 7; col++) {
                if ((row === 0 && col < firstDay) || dayCounter > daysInMonth) {
                    let cell = tableRow.insertCell();
                    cell.classList.add('disabled');
                } else {
                    let cell = tableRow.insertCell();
                    cell.textContent = dayCounter;
                    let currentDate = new Date(currentYear, currentMonth, dayCounter);
                    if (currentDate < today) {
                        cell.classList.add('disabled');
                    } else {
                        checkAvailability(currentDate, cell);
                    }
                    dayCounter++;
                }
            }
        }
    }

    function selectDate(cell) {
        if (selectedDateCell) {
            selectedDateCell.classList.remove('selected-cell');
        }
        selectedDateCell = cell;
        selectedDateCell.classList.add('selected-cell');
        selectedDate = new Date(currentYear, currentMonth, parseInt(cell.textContent));
        updateTimeSlots();
    }

    function updateTimeSlots() {
        if (selectedDate) {
            timeSlotsContainer.innerHTML = "";
            let timeSlots = [];
            if (selectedDate.getDay() >= 4) {
                timeSlots = ['8AM - 11AM', '12PM - 3PM', '4PM - 7PM', '8PM - 11PM'];
            } else {
                timeSlots = ['4PM - 7PM', '8PM - 11PM'];
            }

            const year = selectedDate.getFullYear();
            const month = ('0' + (selectedDate.getMonth() + 1)).slice(-2);
            const day = ('0' + selectedDate.getDate()).slice(-2);
            const formattedDate = `${year}-${month}-${day}`;

            $.ajax({
                url: "modules/check_reservation.php",
                type: 'POST',
                data: { date: formattedDate },
                success: function(response) {
                    const bookedSlots = response.split(',');
                    let availableSlots = false;

                    timeSlots.forEach(slot => {
                        if (!bookedSlots.includes(slot)) {
                            availableSlots = true;
                            let button = document.createElement('button');
                            button.textContent = slot;
                            button.classList.add('time-slot');
                            button.addEventListener('click', () => {
                                selectedSlot = slot;
                                confirmReservation(selectedDate, slot);
                            });
                            timeSlotsContainer.appendChild(button);
                        }
                    });

                    if (!availableSlots) {
                        if (selectedDateCell) {
                            selectedDateCell.classList.add('disabled');
                            selectedDateCell.style.pointerEvents = 'none';
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: " + status + ": " + error);
                }
            });
        }
    }

    function checkAvailability(date, cell) {
        const year = date.getFullYear();
        const month = ('0' + (date.getMonth() + 1)).slice(-2);
        const day = ('0' + date.getDate()).slice(-2);
        const formattedDate = `${year}-${month}-${day}`;

        $.ajax({
            url: "modules/check_reservation.php",
            type: 'POST',
            data: { date: formattedDate },
            success: function(response) {
                const bookedSlots = response.split(',');
                let timeSlots = [];
                if (date.getDay() >= 4) {
                    timeSlots = ['8AM - 11AM', '12PM - 3PM', '4PM - 7PM', '8PM - 11PM'];
                } else {
                    timeSlots = ['4PM - 7PM', '8PM - 11PM'];
                }

                let availableSlots = timeSlots.filter(slot => !bookedSlots.includes(slot)).length > 0;

                if (!availableSlots) {
                    cell.classList.add('disabled');
                    cell.style.pointerEvents = 'none';
                } else {
                    cell.addEventListener('click', () => {
                        selectDate(cell);
                    });
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: " + status + ": " + error);
            }
        });
    }

    function confirmReservation(date, slot) {
        const year = date.getFullYear();
        const month = ('0' + (date.getMonth() + 1)).slice(-2);
        const day = ('0' + date.getDate()).slice(-2);
        const formattedDate = `${year}-${month}-${day}`;

        const confirmed = confirm(`Do you want to book a reservation for ${date.toLocaleDateString()} at ${slot}?`);
        if (confirmed) {
            const personalDetailsForm = document.createElement('form');
            personalDetailsForm.setAttribute('id', 'frmaddthesis');
            personalDetailsForm.setAttribute('enctype', 'multipart/form-data');
            personalDetailsForm.innerHTML = `
                <br>
                <div class="form-group">
                    <label for="txt_date">Date</label>
                    <input type="date" class="form-control" id="txt_date" name="txt_date" value="${formattedDate}" readonly>
                </div>
                <div class="form-group">
                    <label for="txt_time">Time</label>
                    <input type="text" class="form-control" id="txt_time" name="txt_time" value="${slot}" readonly>
                </div>
                <div class="form-group">
                    <label for="txt_name">Name</label>
                    <input type="text" class="form-control" id="txt_name" name="txt_name" pattern="[A-Za-z ]+" title="Please enter letters only">
                </div>
                <div class="form-group">
                    <label for="txt_home_address">Home Address</label>
                    <input type="text" class="form-control" id="txt_home_address" name="txt_home_address">
                </div>
                <div class="form-group">
                    <label for="txt_contact_no">Contact No.</label>
                    <input type="text" class="form-control" id="txt_contact_no" name="txt_contact_no" pattern="[0-9]+" title="Please enter numbers only">
                </div>
                <div class="form-group">
                    <label for="txt_email_address">E-mail Address</label>
                    <input type="email" class="form-control" id="txt_email_address" name="txt_email_address" title="Please enter a valid email address">
                </div>
                <button type="submit" class="btn btn-primary" id="btnsave">Submit</button>
                <button type="button" class="btn btn-secondary" id="btncancel">Cancel</button>
                <div class="error-message" id="error-message"></div>
            `;

            timeSlotsContainer.innerHTML = "";
            timeSlotsContainer.appendChild(personalDetailsForm);

            $("#btncancel").click(function() {
                document.location = "./?page=booknow";
            });

            $("#frmaddthesis").submit(function(event) {
                event.preventDefault();
                if (validateForm()) {
                    var formData = new FormData(this);

                    $.ajax({
                        url: "modules/submit_booking.php",
                        type: 'POST',
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function(response) {
                            if (response == 'success') {
                                alert("Successfully Saved");
                                document.location = "./?page=booknow";
                            } else {
                                alert(response);
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error("AJAX Error: " + status + ": " + error);
                        }
                    });
                }
            });
        }
    }

    function validateForm() {
        const fields = ['#txt_name', '#txt_home_address', '#txt_contact_no', '#txt_email_address'];
        let valid = true;
        const name = document.querySelector('#txt_name');
        const contactNo = document.querySelector('#txt_contact_no');
        const email = document.querySelector('#txt_email_address');
        
        fields.forEach(field => {
            const input = document.querySelector(field);
            if (input.value.trim() === '') {
                valid = false;
            }
        });

        if (!name.checkValidity()) {
            valid = false;
        }

        if (!contactNo.checkValidity()) {
            valid = false;
        }

        if (!email.checkValidity()) {
            valid = false;
        }

        if (!valid) {
            document.getElementById('error-message').innerHTML = 'Please fill up the required details.';
        }
        return valid;
    }

    prevButton.addEventListener("click", function() {
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        updateCalendar();
    });

    nextButton.addEventListener("click", function() {
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        updateCalendar();
    });

    updateCalendar();
    </script>
</body>
</html>
