<?php
include 'db_connect.php';

$date = $_POST['date'];

$sql = "SELECT time_slot FROM reservations WHERE date = ?";
$stmt = $connector->prepare($sql);
$stmt->bind_param("s", $date);
$stmt->execute();
$result = $stmt->get_result();

$bookedSlots = [];
while ($row = $result->fetch_assoc()) {
    $bookedSlots[] = $row['time_slot'];
}

$stmt->close();
$connector->close();

echo implode(',', $bookedSlots);
?>
