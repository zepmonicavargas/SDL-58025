<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        // Move the reservation to the 'completed' table
        $sql = "INSERT INTO completed (date, time_slot, name, home_address, contact_no, email_address, completed_at)
                SELECT date, time_slot, name, home_address, contact_no, email_address, NOW()
                FROM reservations WHERE id = ?";
        $stmt = $connector->prepare($sql);
        $stmt->bind_param("i", $id);
        if($stmt->execute()) {
            // Delete the reservation from the 'reservations' table
            $sql = "DELETE FROM reservations WHERE id = ?";
            $stmt = $connector->prepare($sql);
            $stmt->bind_param("i", $id);
            $stmt->execute();
            echo 'success';
        } else {
            echo 'error';
        }
        $stmt->close();
    } else {
        echo 'Invalid ID';
    }
}

$connector->close();
?>
