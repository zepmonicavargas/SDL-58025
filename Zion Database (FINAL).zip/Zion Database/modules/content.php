<body style="background-color:#f5f5f5;">
<?php 
$page = "";
if (isset($_GET['page'])) {
    $page = $_GET['page'];
}
if (!isset($_SESSION['logged_in'])) {
    if ($page !== "login") { // Check if the current page is not "login"
        include("header.php"); // Include the header if the current page is not "login"
    }
    switch($page){
        case "":
        case "homepage":
            include ("homepage.php");
            break;
        case "about":
            include ("about.php");
            break;
        case "faqs":
            include ("faqs.php");
            break;
        case "services":
            include ("services.php");
            break;
        case "booknow":
            include ("booknow.php");
            break;
        case "login":
            include("login.php");
            break;
        default:
            include("error.php");
    }
} else if ($_SESSION['level'] == "1") {
    include("header_admin.php");
    switch($page){
        case "":
        case "homeadmin":
            include ("homeadmin.php");
            break;
        case "orders_admin":
            include ("orders_admin.php");
            break;
        case "servicesadmin":
            include ("servicesadmin.php");
            break;
        case "orders_admin":
            include ("orders_admin.php");
            break;
        case "completed_admin":
            include ("completed_admin.php");
            break;
        default:
            include("error.php");
    }
}
?>
