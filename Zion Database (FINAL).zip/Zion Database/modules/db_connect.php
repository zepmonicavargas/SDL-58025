<?php
$username = "root";
$password = "";
$server   = "localhost";
$dbasename = "zion_db";

$connector = mysqli_connect($server, $username, $password);
mysqli_select_db($connector, $dbasename);
?>