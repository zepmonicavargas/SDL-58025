<?php
include('db_connect.php'); // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['c_id'])) {
        $c_id = $_POST['c_id'];

        // Validate the c_id to ensure it is an integer
        if (filter_var($c_id, FILTER_VALIDATE_INT)) {
            // Prepare the DELETE query
            $query = "DELETE FROM tbl_images WHERE c_id = ?";
            $stmt = $connector->prepare($query);
            $stmt->bind_param("i", $c_id);

            if ($stmt->execute()) {
                // Get the image file name from the database before deleting
                $imageQuery = "SELECT image_name FROM tbl_images WHERE c_id = ?";
                $imageStmt = $connector->prepare($imageQuery);
                $imageStmt->bind_param("i", $c_id);
                $imageStmt->execute();
                $imageResult = $imageStmt->get_result();
                $imageRow = $imageResult->fetch_assoc();
                $imageStmt->close();

                if ($imageRow) {
                    $imagePath = 'http://localhost/Zion%20Database/modules/carousel/' . $imageRow['image_name'];
                    // Check if the file exists and delete it
                    if (file_exists($imagePath)) {
                        unlink($imagePath);
                    }
                }

                echo json_encode(['success' => true, 'message' => 'Image deleted successfully.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete image from database.']);
            }

            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid image ID.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Image ID not provided.']);
    }

    // Close the database connection
    $connector->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>
