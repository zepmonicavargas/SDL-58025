<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        // Delete the reservation from the 'reservations' table
        $sql = "DELETE FROM reservations WHERE id = ?";
        $stmt = $connector->prepare($sql);
        $stmt->bind_param("i", $id);
        if($stmt->execute()) {
            echo 'success';
        } else {
            echo 'error';
        }
        $stmt->close();
    } else {
        echo 'Invalid ID';
    }
}

$connector->close();
?>
