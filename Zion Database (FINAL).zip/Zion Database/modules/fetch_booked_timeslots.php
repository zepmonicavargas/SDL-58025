<?php
require 'db_connect.php'; // Assuming you have a file to handle database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'];
    $time_slot = $_POST['time_slot'];

    // Prepare and execute the query
    $stmt = $connector->prepare("SELECT COUNT(*) FROM reservations WHERE date = ? AND time_slot = ?");
    $stmt->bind_param('ss', $date, $time_slot);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        echo 'unavailable';
    } else {
        echo 'available';
    }
}
?>
