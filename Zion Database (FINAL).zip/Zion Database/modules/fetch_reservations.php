<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['year']) && isset($_POST['month'])) {
        $year = $_POST['year'];
        $month = $_POST['month'];

        // Prepare SQL to fetch reservations for the given month
        $sql = "SELECT date FROM reservations WHERE YEAR(date) = ? AND MONTH(date) = ?";
        $stmt = $connector->prepare($sql);
        $stmt->bind_param("ii", $year, $month);
        $stmt->execute();
        $result = $stmt->get_result();

        $reservations = [];
        while ($row = $result->fetch_assoc()) {
            $reservations[] = $row['date'];
        }

        echo json_encode($reservations);
        $stmt->close();
    } elseif (isset($_POST['selected_date'])) {
        $selected_date = $_POST['selected_date'];

        // Prepare SQL to fetch reservations for the selected date
        $sql = "SELECT * FROM reservations WHERE date = ?";
        $stmt = $connector->prepare($sql);
        $stmt->bind_param("s", $selected_date);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo '<table id="reservationsTable" style="width:100%; border-collapse: collapse;">';
            echo '<thead><tr><th>Date</th><th>Time Slot</th><th>Name</th><th>Home Address</th><th>Contact No</th><th>Email Address</th><th>Created At</th><th>Actions</th></tr></thead>';
            echo '<tbody>';
            while ($row = $result->fetch_assoc()) {
                echo '<tr data-id="' . $row['id'] . '">';
                echo '<td class="no-wrap">' . $row['date'] . '</td>';
                echo '<td class="no-wrap">' . $row['time_slot'] . '</td>';
                echo '<td class="no-wrap">' . $row['name'] . '</td>';
                echo '<td class="no-wrap">' . $row['home_address'] . '</td>';
                echo '<td class="no-wrap">' . $row['contact_no'] . '</td>';
                echo '<td class="no-wrap">' . $row['email_address'] . '</td>';
                echo '<td class="no-wrap">' . $row['created_at'] . '</td>';
                echo '<td class="no-wrap">';
                echo '<button class="complete-btn" onclick="handleComplete(this)">Complete</button>';
                echo '<button class="delete-btn" onclick="handleDelete(this)">Delete</button>';
                echo '</td>';
                echo '</tr>';
            }
            echo '</tbody>';
            echo '</table>';
        }
        $stmt->close();
    }
}

$connector->close();
?>
