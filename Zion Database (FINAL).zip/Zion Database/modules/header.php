<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="Logo.png">
    <title>Zion Colors</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Abril+Fatface|Poppins">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Spectral|Rubik">
    <style>
        body {
            font-family: Poppins, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #FDFD96, #F8C8DC);
        }
        header {
            background: linear-gradient(to right, #ff66a3, #CF9FFF);
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            font-family: 'Abril Fatface', serif;
            margin: 0;
            color: #fff;
            font-size: 40px;
            letter-spacing: 2px;
        }
        nav {
            background-color: #ff66a3;
            padding: 10px 0;
            text-align: center;
        }
        nav ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }
        nav ul li {
            display: inline;
            margin: 0 10px;
        }
        nav ul li a {
            color: #fff; /* Set default text color to white */
            text-decoration: none;
            font-size: 18px;
        }
        nav ul li a.active {
            background-color: #fff;
            color: #ff66a3;
        }
    </style>
</head>
<body>
    <header>
        <h1>Zion Colors</h1>
    </header>
    <nav>
        <ul>
            <li><a id="homepage" href="#">Home</a></li>
            <li><a id="about" href="#">About</a></li>
            <li><a id="faqs" href="#">FAQs</a></li>
            <li><a id="services" href="#">Services</a></li>
            <li><a id="booknow" href="#">Book Now</a></li>
        </ul>
    </nav>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function(){
            // Function to remove the "active" class from all links
            function removeActiveClass() {
                $("nav ul li a").removeClass("active");
            }

            // Click event handlers for navigation links
            $("#homepage").click(function(){
                removeActiveClass();
                $(this).addClass("active");
                document.location = "./?page=homepage";
            });

            $("#about").click(function(){
                removeActiveClass();
                $(this).addClass("active");
                document.location = "./?page=about";
            });

            $("#faqs").click(function(){
                removeActiveClass();
                $(this).addClass("active");
                document.location = "./?page=faqs";
            });

            $("#services").click(function(){
                removeActiveClass();
                $(this).addClass("active");
                document.location = "./?page=services";
            });

            $("#booknow").click(function(){
                removeActiveClass();
                $(this).addClass("active");
                document.location = "./?page=booknow";
            });

            // Set initial active class based on the current page
            var currentPage = "<?php echo isset($_GET['page']) ? $_GET['page'] : ''; ?>";
            $("#" + currentPage).addClass("active");
        });
    </script>
</body>
</html>
