<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="Logo.png">
    <title>Zion Colors | Admin</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Abril+Fatface|Poppins">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Spectral|Rubik">
    <style>
        body {
            font-family: Poppins, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #FDFD96, #F8C8DC);
        }
        header {
            background: linear-gradient(to right, #ff66a3, #CF9FFF);
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            font-family: 'Abril Fatface', serif;
            margin: 0;
            color: #fff;
            font-size: 40px;
            letter-spacing: 2px;
        }
        nav {
            background-color: #ff66a3;
            padding: 10px 0;
            text-align: center;
        }
        nav ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }
        nav ul li {
            display: inline;
            margin: 0 10px;
        }
        nav ul li a, nav ul li button {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            background-color: transparent;
            border: none;
            cursor: pointer;
            padding: 0;
        }
        nav ul li a.active, nav ul li button.active {
            background-color: #fff;
            color: #ff66a3;
        }
        .card-header {
            background-color: #ff66a3;
            color: white;
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <h1>Zion Colors</h1>
    </header>
    <nav>
        <ul>
            <li><a id="homepage" href="#" onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">Home</a></li>
            <li><a id="services" href="#" onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">Services</a></li>
            <li><a id="orders_admin" href="#" onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">Orders</a></li>
            <li><button id="logout" onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'" data-toggle="modal" data-target="#logoutModal">Logout</button></li>
        </ul>
    </nav>

    <!-- Logout Modal -->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoutModalLabel">Logout Confirmation</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Are you sure you want to logout?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="logout()">Logout</button>
                </div>
            </div>
        </div>
    </div>

    <script>
    $(document).ready(function(){
        // Function to remove the "active" class from all links and remove borders
        function removeActiveClass() {
            $("nav ul li a, nav ul li button").removeClass("active");
        }

        // Function to remove the border from all links
        function removeBorder() {
            $("nav ul li a").css("border", "none");
        }

        // Function to add border to the clicked link
        function addBorder(element) {
            $(element).css("border", "1px solid #fff");
        }

        $("#homepage").click(function(){
            removeActiveClass(); // Remove active class from all links
            removeBorder(); // Remove border from all links
            $(this).addClass("active"); // Add active class to clicked link
            addBorder(this); // Add border to clicked link
            document.location = "./?page=homeadmin";
        });

        $("#services").click(function(){
            removeActiveClass(); // Remove active class from all links
            removeBorder(); // Remove border from all links
            $(this).addClass("active"); // Add active class to clicked link
            addBorder(this); // Add border to clicked link
            document.location = "./?page=servicesadmin";
        });

        $("#orders_admin").click(function(){
            removeActiveClass(); // Remove active class from all links
            removeBorder(); // Remove border from all links
            $(this).addClass("active"); // Add active class to clicked link
            addBorder(this); // Add border to clicked link
            document.location = "./?page=orders_admin";
        });

        // Set initial active class and border based on the current page
        var currentPage = "<?php echo isset($_GET['page']) ? $_GET['page'] : ''; ?>";
        if (currentPage === 'homeadmin') {
            $("#homepage").addClass("active");
            addBorder("#homepage");
        } else if (currentPage === 'servicesadmin') {
            $("#services").addClass("active");
            addBorder("#services");
        } else if (currentPage === 'orders_admin' || currentPage === 'completed_admin') {
            $("#orders_admin").addClass("active");
            addBorder("#orders_admin");
        } else {
            $("#" + currentPage).addClass("active");
            addBorder("#" + currentPage);
        }
    });

    // Logout function
    function logout() {
        // Call your logout logic here
        document.location = "./?logout=logout&page=homepage";
    }
</script>


</body>
</html>
