<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="Logo.png">

    <title>Zion Colors | Home</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Abril+Fatface|Poppins">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Spectral|Rubik">
    <style>
        body {
            font-family: Poppins, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #FDFD96, #F8C8DC);
        }
        header {
            background: linear-gradient(to right, #ff66a3, #CF9FFF); 
            padding: 20px 0;
            text-align: center;
		}
        header h1 {
		    font-family: 'Abril Fatface', serif;
            margin: 0;
            color: #fff;
            font-size: 40px;
			letter-spacing: 2px;
        }
        nav {
            background-color: #ff66a3;
            padding: 10px 0;
            text-align: center;
        }
        nav ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }
        nav ul li {
            display: inline;
            margin: 0 10px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
        }
		nav ul li a.active {
            background-color: #fff; /* Change to your desired active background color */
            color: #ff66a3; /* Change to your desired active text color */
			border-radius: 15px;
            padding: 5px;
        }
        .carousel {
            margin: 40px;
            position: relative; /* Add position relative to enable absolute positioning of buttons */
        }
        .carousel-inner img {
            width: 100%;
            height: 500px; /* Adjust the height as needed */
            object-fit: cover;
        }
        .carousel-edit-btn, .carousel-add-btn {
            position: absolute;
            top: 20px;
            z-index: 1051;
        }
        .carousel-edit-btn {
            right: 20px;
        }
        .carousel-add-btn {
            left: 20px;
        }
        .hero-section {
            background-size: cover;
            background-position: center;
            height: 400px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #fff;
        }
        .hero-section h2 {
            font-size: 48px;
            margin: 0;
        }
        .container-home {
            max-width: 1200px;
            margin: 40px auto; /* Add margin to center the content */
            padding: 40px;
        }
        .btn-guest {
            background-color: #87ceeb; /* Pastel blue */
            color: white;
            padding: 15px 25px; /* Adjusted padding */
            border: none;
            border-radius: 25px; /* Rounded corners */
            text-decoration: none;
            font-size: 18px; /* Bigger font size */
            cursor: pointer;
        }
        .btn-guest:hover {
            background-color: #87ceeb; /* Lighter pastel blue on hover */
        }
        footer {
            background: linear-gradient(to right, #ff66a3, #CF9FFF);
            padding: 20px 0;
            text-align: center;
            color: #fff;
        }
        .contact-section {
            font-family: Spectral, serif;
			background-color: #f8f9fa; /* Light gray background */
            padding: 60px;
        }
		.icon-links {
    		display: block; /* Display the icons and text as block elements */
   		    margin-bottom: 20px; /* Add space between each icon and text */
		}
		.icons {
 		    width: 40px; /* Adjust width as needed */
  		    height: 40px; /* Adjust height as needed */
  		    margin-right: 27px; /* Add some space between icons */
		}
        .social-media {
            font-family: Spectral, serif;
			background-color: #f8f9fa; /* Light gray background */
            padding: 60px;
        }
		.icon-link {
    		display: block; /* Display the icons and text as block elements */
   		    margin-bottom: 8px; /* Add space between each icon and text */
		}
        .icon {
            width: 50px; /* Adjust size as needed */
            height: 50px; /* Adjust size as needed */
            margin-right: 20px; /* Add some space between icons */
			display: inline-block; /* Display the icons inline */
            vertical-align: middle; /* Align vertically with the text */
        }
		.icon-text {
			display: inline-block; /* Display the alt text inline */
            vertical-align: middle; /* Align vertically with the icon */
            margin-left: 1px; /* Add some space between the icon and the text */
            color: black; /* Set the color of the alt text */
        }
        .current-photos {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
    }

    .photo-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 10px;
        width: 100%;
    }

    .photo {
        position: relative;
    }

    .carousel-image {
        width: 100%;
        height: auto;
        border-radius: 5px;
        object-fit: cover;
    }

    .remove-photo {
        position: absolute;
        top: 5px;
        right: 5px;
        background: rgba(0, 0, 0, 0.5);
        color: white;
        border: none;
        border-radius: 50%;
        width: 20px;
        height: 20px;
        display: flex;
        justify-content: center;
        align-items: center;
        cursor: pointer;
    }

    .remove-photo:hover {
        background: rgba(255, 0, 0, 0.7);
    }
    .carousel-add-btn {
        margin-top: 20px; 
        margin-left: 1210px; 
	    margin-bottom: 10px;
        z-index: 1051;
    }
    .carousel-edit-btn {
        margin-top: 70px; 
        margin-right: 10px; 
	    margin-bottom: 10px;
        z-index: 1051;
    }
    #socialMediaCategory option:first-child {
    display: none;
    }
    </style>
	
</head>
<body>
    <?php
include('db_connect.php'); // Include your database connection file

// Check if the connection is successful
if ($connector) {
    $query = "SELECT c_id, c_img FROM tbl_images"; // Query to select all columns from the "tbl_images" table
    $result = mysqli_query($connector, $query); // Execute the query

    if ($result) {
        echo '<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">';
        echo '<div class="carousel-inner">';
        
        $active = 'active'; // Variable to set the first item as active
        while ($row = mysqli_fetch_assoc($result)) {
            $c_id = $row['c_id'];
            $imageFileName = $row['c_img'];
            $imageSrc = 'http://localhost/Zion%20Database/modules/carousel/' . $c_id . '.' . $imageFileName;

            echo '<div class="carousel-item ' . $active . '">';
            echo '<img class="d-block w-100" src="' . $imageSrc . '" alt="Slide ' . $c_id . '">';
            echo '</div>';

            $active = ''; // Only the first item should be active
        }

        echo '</div>';
        echo '<a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">';
        echo '<span class="carousel-control-prev-icon" aria-hidden="true"></span>';
        echo '<span class="sr-only">Previous</span>';
        echo '</a>';
        echo '<a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">';
        echo '<span class="carousel-control-next-icon" aria-hidden="true"></span>';
        echo '<span class="sr-only">Next</span>';
        echo '</a>';
        echo '<button class="btn btn-danger carousel-edit-btn" data-toggle="modal" data-target="#editModalCarousel" >🗑 Delete</button>';
        echo '<button class="btn btn-info carousel-add-btn" data-toggle="modal" data-target="#addImageModal">📸 Add Image</button>';
        echo '</div>';
    } else {
        echo 'Error executing the query: ' . mysqli_error($connector);
    }

    mysqli_close($connector); // Close the database connection
} else {
    echo 'Error connecting to the database: ' . mysqli_connect_error();
}
?>


    <?php
include('db_connect.php'); // Include your database connection file

// Check if the connection is successful
if ($connector) {
    $query = "SELECT category, url, text FROM socials"; // Query to select relevant columns from the "socials" table
    $result = mysqli_query($connector, $query); // Execute the query

    if ($result) {
        // Initialize arrays for categories
        $contactUs = [];
        $socialMedia = [];

        // Fetch data from the database
        while ($row = mysqli_fetch_assoc($result)) {
            $category = $row['category'];
            $url = $row['url'];
            $text = $row['text'];
            $icon = ''; // Initialize the icon variable

            // Determine the icon based on the category
            if ($category == 'Facebook') {
                $icon = 'https://static.vecteezy.com/system/resources/previews/018/930/698/non_2x/facebook-logo-facebook-icon-transparent-free-png.png';
            } elseif ($category == 'Email') {
                $icon = 'https://icons.veryicon.com/png/o/internet--web/billion-square-cloud/mail-213.png';
            } elseif ($category == 'Address') {
                $icon = 'https://cdn-icons-png.freepik.com/256/331/331810.png';
            } elseif ($category == 'Instagram') {
                $icon = 'https://png.pngtree.com/png-clipart/20180524/ourmid/pngtree-instagram-social-media-icon-png-image_3572472.png';
            } elseif ($category == 'TikTok') {
                $icon = 'https://static.vecteezy.com/system/resources/previews/018/930/574/non_2x/tiktok-logo-tikok-icon-transparent-tikok-app-logo-free-png.png';
            } elseif ($category == 'Contact Number') {
                $icon = 'https://cdn-icons-png.freepik.com/512/455/455705.png'; // Use appropriate icon for contact number
            }

            // Populate the respective arrays based on the category
            if (in_array($category, ['Contact Number', 'Email', 'Address',])) {
                $contactUs[] = [
                    'url' => $url,
                    'text' => $text,
                    'icon' => $icon,
                ];
            } else {
                $socialMedia[] = [
                    'url' => $url,
                    'text' => $text,
                    'icon' => $icon,
                ];
            }
        }

        // Close the database connection
        mysqli_close($connector);
    } else {
        echo "Error: " . mysqli_error($connector);
        exit;
    }
} else {
    echo "Failed to connect to the database.";
    exit;
}
?>
<!-- Modal for Editing Carousel -->
<div class="modal fade" id="editModalCarousel" tabindex="-1" role="dialog" aria-labelledby="editModalCarouselLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalCarouselLabel">Delete Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="current-photos">
                    <div class="photo-grid">
                        <!-- Display existing photos -->
                        <?php
                        include('db_connect.php'); // Include your database connection file

                        // Check if the connection is successful
                        if ($connector) {
                            $query = "SELECT c_id, c_img FROM tbl_images"; // Query to select all columns from the "tbl_images" table
                            $result = mysqli_query($connector, $query); // Execute the query

                            if ($result) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    $c_id = $row['c_id'];
                                    $imageFileName = $row['c_img'];
                                    $imageSrc = 'http://localhost/Zion Database/modules/carousel/' . $c_id . '.' . $imageFileName;

                                    echo '<div class="photo">';
                                    echo '<img src="' . $imageSrc . '" alt="Slide ' . $c_id . '" class="carousel-image">';
                                    echo '<button class="remove-photo" data-photo="' . $c_id . '" onclick="openDeleteConfirmationModal('. $c_id .')">&times;</button>'; // Add onclick event to delete photo
                                    echo '</div>';
                                }
                            } else {
                                echo "Error: " . mysqli_error($connector);
                            }

                            // Close the database connection
                            mysqli_close($connector);
                        } else {
                            echo "Failed to connect to the database.";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="deleteConfirmationModal" tabindex="-1" role="dialog" aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirmation</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             <div class="modal-body">
                 Are you sure you want to delete this image?
             </div>
             <div class="modal-footer">
                 <button type="button" class="btn btn-danger" id="confirmDeleteButton" onclick="deleteimageConfirmed()">Delete</button>
                 <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
             </div>
         </div>
     </div>
 </div>

 <div class="modal fade" id="editSocialMediaModal" tabindex="-1" role="dialog" aria-labelledby="editSocialMediaModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">  
                <h5 class="modal-title" id="editSocialMediaModalLabel">Edit Information</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="socialMediaForm">
                    <!-- Category dropdown -->
                    <div class="form-group">
                        <label for="socialMediaCategory">Category</label>
                        <select class="form-control" id="socialMediaCategory" name="socialMediaCategory">
                            <option value="" disabled selected>Select Category</option>
                            <option value="Contact Number">Contact Number</option>
                            <option value="Email">Email</option>
                            <option value="Address">Address</option>
                            <option value="Instagram">Instagram</option>
                            <option value="Tiktok">Tiktok</option>
                            <option value="Facebook">Facebook</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="socialMediaUrl">URL</label>
                        <input type="text" class="form-control" id="socialMediaUrl" name="socialMediaUrl">
                    </div>
                    <div class="form-group">
                        <label for="socialMediaText">Text</label>
                        <input type="text" class="form-control" id="socialMediaText" name="socialMediaText">
                    </div>
                    <button type="button" class="btn btn-primary" onclick="saveSocialMediaChanges()">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>
    <!-- Add Image Modal HTML -->
    <div class="modal fade" id="addImageModal" tabindex="-1" role="dialog" aria-labelledby="addImageModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addImageModalLabel">Add Image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="addImageForm" action="http://localhost/Zion%20Database/modules/upload_image.php" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="imageFile">Choose Image</label>
                            <input type="file" class="form-control-file" id="imageFile" name="imageFile" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Upload</button>
                    </form>
                </div>
            </div>
        </div>
    </div>



<div class="container-home">
    <div class="row">
        <div class="col-lg-6 contact-section"> <!-- Contact Us section -->
            <h3>Contact Us:</h3>
            <div class="social-icons">
                <?php foreach ($contactUs as $contact) { ?>
                    <a href="<?php echo $contact['url']; ?>" target="_blank" class="icon-links">
                        <img src="<?php echo $contact['icon']; ?>" alt="Contact" class="icons">
                        <span class="icon-text"><?php echo $contact['text']; ?></span>
                    </a>
                <?php } ?>
            </div>
        </div>
        <div class="col-lg-6 social-media"> <!-- Social Media section -->
            <h3>Social Media Platforms:</h3>
            <div class="social-icons">
                <?php foreach ($socialMedia as $social) { ?>
                    <a href="<?php echo $social['url']; ?>" target="_blank" class="icon-link">
                        <img src="<?php echo $social['icon']; ?>" alt="Social Media" class="icon">
                        <span class="icon-text"><?php echo $social['text']; ?></span>
                    </a>
                    <button id="editButtonContainer" class="btn btn-secondary" style="font-family: Poppins, sans-serif; position: absolute; top: 20px; right: 20px; z-index: 1051;" data-toggle="modal" data-target="#editSocialMediaModal">✎ Edit</button>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
    
    <footer>
        <p>&copy; 2024 Zion Colors. All rights reserved.</p>
    </footer>

<script>
    function openDeleteConfirmationModal(c_id) {
        $('#deleteConfirmationModal').modal('show');
        document.getElementById('confirmDeleteButton').onclick = function() {
            deleteImageConfirmed(c_id);
        };
    }

    function deleteImageConfirmed(c_id) {
        $.ajax({
            url: 'http://localhost/Zion%20Database/modules/delete_image.php',
            type: 'POST',
            data: {
                c_id: c_id
            },
            success: function(response) {
                $('#deleteConfirmationModal').modal('hide');
                // Automatically refresh the browser
                location.reload();
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
                alert('Failed to delete image. Please try again.');
            }
        });
    }


function saveSocialMediaChanges() {
    // Get form data
    var category = $('#socialMediaCategory').val();
    var url = $('#socialMediaUrl').val();
    var text = $('#socialMediaText').val();

    // Perform validation if necessary

    // Send data to server
    $.ajax({
        url: 'http://localhost/Zion%20Database/modules/update_socials.php', // Your server endpoint to handle the update
        method: 'POST',
        data: {
            category: category,
            url: url,
            text: text
        },
        success: function(response) {
            // Handle success
            alert('Social media information updated successfully.');
            // Optionally, close the modal
            $('#editSocialMediaModal').modal('hide');
            // Optionally, refresh the page or update the UI accordingly
            location.reload();
        },
        error: function(error) {
            // Handle error
            alert('Failed to update social media information.');
        }
    });
}




    </script>
</body>
</html>