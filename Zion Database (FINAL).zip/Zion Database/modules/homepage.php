<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="Logo.png">
    
    <title>Zion Colors | Home</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Abril+Fatface|Poppins">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Spectral|Rubik">
    <style>
        body {
            font-family: Poppins, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #FDFD96, #F8C8DC); /* Yellow to Pink gradient */
        }
        header {
            background: linear-gradient(to right, #ff66a3, #CF9FFF); /* Fuchsia Pink to Purple gradient */
            padding: 20px 0;
            text-align: center;
		}
        header h1 {
		    font-family: 'Abril Fatface', serif;
            margin: 0;
            color: #fff;
            font-size: 40px;
			letter-spacing: 2px;
        }
        nav {
            background-color: #ff66a3;
            padding: 10px 0;
            text-align: center;
        }
        nav ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }
        nav ul li {
            display: inline;
            margin: 0 10px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
        }
		nav ul li a.active {
            background-color: #fff; /* Change to your desired active background color */
            color: #ff66a3; /* Change to your desired active text color */
			border-radius: 15px;
			padding: 5px;
        }
        .carousel {
            margin: 40px;
        }
        .carousel-inner img {
            width: 100%;
            height: 500px; /* Adjust the height as needed */
            object-fit: cover;
        }
        .hero-section {
            background-size: cover;
            background-position: center;
            height: 400px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #fff;
        }
        .hero-section h2 {
            font-size: 48px;
            margin: 0;
        }
        .container-home {
            max-width: 1200px;
            margin: 40px auto; /* Add margin to center the content */
            padding: 40px;
        }
        .btn-guest {
            background-color: #87ceeb; /* Pastel blue */
            color: white;
            padding: 15px 25px; /* Adjusted padding */
            border: none;
            border-radius: 25px; /* Rounded corners */
            text-decoration: none;
            font-size: 18px; /* Bigger font size */
            cursor: pointer;
        }
        .btn-guest:hover {
            background-color: #005F6B; /* Lighter pastel blue on hover */
			color: white;
        }
        footer {
            background: linear-gradient(to right, #ff66a3, #CF9FFF); /* Fuchsia Pink to Purple gradient */
            padding: 20px 0;
            text-align: center;
            color: #fff;
        }
        .contact-section {
            font-family: Spectral, serif;
			background-color: #f8f9fa; /* Light gray background */
            padding: 60px;
        }
		.icon-links {
    		display: block; /* Display the icons and text as block elements */
   		    margin-bottom: 20px; /* Add space between each icon and text */
		}
		.icons {
 		    width: 40px; /* Adjust width as needed */
  		    height: 40px; /* Adjust height as needed */
  		    margin-right: 27px; /* Add some space between icons */
		}
        .social-media {
            font-family: Spectral, serif;
			background-color: #f8f9fa; /* Light gray background */
            padding: 60px;
        }
		.icon-link {
    		display: block; /* Display the icons and text as block elements */
   		    margin-bottom: 8px; /* Add space between each icon and text */
		}
        .icon {
            width: 50px; /* Adjust size as needed */
            height: 50px; /* Adjust size as needed */
            margin-right: 20px; /* Add some space between icons */
			display: inline-block; /* Display the icons inline */
            vertical-align: middle; /* Align vertically with the text */
        }
		.icon-text {
			display: inline-block; /* Display the alt text inline */
            vertical-align: middle; /* Align vertically with the icon */
            margin-left: 1px; /* Add some space between the icon and the text */
            color: black; /* Set the color of the alt text */
        }
    </style>
	
</head>
<body>
<?php
include('db_connect.php'); // Include your database connection file

// Check if the connection is successful
if ($connector) {
    $query = "SELECT c_id, c_img FROM tbl_images"; // Query to select all columns from the "tbl_images" table
    $result = mysqli_query($connector, $query); // Execute the query

    if ($result) {
        echo '<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">';
        echo '<div class="carousel-inner">';
        
        $active = 'active'; // Variable to set the first item as active
        while ($row = mysqli_fetch_assoc($result)) {
            $c_id = $row['c_id'];
            $imageFileName = $row['c_img'];
            $imageSrc = 'http://localhost/Zion%20Database/modules/carousel/' . $c_id . '.' . $imageFileName;

            echo '<div class="carousel-item ' . $active . '">';
            echo '<img class="d-block w-100" src="' . $imageSrc . '" alt="Slide ' . $c_id . '">';
            echo '</div>';

            $active = ''; // Only the first item should be active
        }

        echo '</div>';
        echo '<a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">';
        echo '<span class="carousel-control-prev-icon" aria-hidden="true"></span>';
        echo '<span class="sr-only">Previous</span>';
        echo '</a>';
        echo '<a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">';
        echo '<span class="carousel-control-next-icon" aria-hidden="true"></span>';
        echo '<span class="sr-only">Next</span>';
        echo '</a>';
        echo '</div>';
    } else {
        echo "Error: " . mysqli_error($connector);
    }

    // Close the database connection
    mysqli_close($connector);
} else {
    echo "Failed to connect to the database.";
}
?>
    <div class="container-home text-center mt-4"> <!-- Adjusted container, text centering, and margin top -->
    <button class="btn-guest" onclick="document.location = './?page=booknow'">Continue as guest</button>
    </div>
    <?php
include('db_connect.php'); // Include your database connection file

// Check if the connection is successful
if ($connector) {
    $query = "SELECT category, url, text FROM socials"; // Query to select relevant columns from the "socials" table
    $result = mysqli_query($connector, $query); // Execute the query

    if ($result) {
        // Initialize arrays for categories
        $contactUs = [];
        $socialMedia = [];

        // Fetch data from the database
        while ($row = mysqli_fetch_assoc($result)) {
            $category = $row['category'];
            $url = $row['url'];
            $text = $row['text'];
            $icon = ''; // Initialize the icon variable

            // Determine the icon based on the category
            if ($category == 'Facebook') {
                $icon = 'https://static.vecteezy.com/system/resources/previews/018/930/698/non_2x/facebook-logo-facebook-icon-transparent-free-png.png';
            } elseif ($category == 'Email') {
                $icon = 'https://icons.veryicon.com/png/o/internet--web/billion-square-cloud/mail-213.png';
            } elseif ($category == 'Address') {
                $icon = 'https://cdn-icons-png.freepik.com/256/331/331810.png';
            } elseif ($category == 'Instagram') {
                $icon = 'https://png.pngtree.com/png-clipart/20180524/ourmid/pngtree-instagram-social-media-icon-png-image_3572472.png';
            } elseif ($category == 'TikTok') {
                $icon = 'https://static.vecteezy.com/system/resources/previews/018/930/574/non_2x/tiktok-logo-tikok-icon-transparent-tikok-app-logo-free-png.png';
            } elseif ($category == 'Contact Number') {
                $icon = 'https://cdn-icons-png.freepik.com/512/455/455705.png'; // Use appropriate icon for contact number
            }

            // Populate the respective arrays based on the category
            if (in_array($category, ['Contact Number', 'Email', 'Address',])) {
                $contactUs[] = [
                    'url' => $url,
                    'text' => $text,
                    'icon' => $icon,
                ];
            } else {
                $socialMedia[] = [
                    'url' => $url,
                    'text' => $text,
                    'icon' => $icon,
                ];
            }
        }

        // Close the database connection
        mysqli_close($connector);
    } else {
        echo "Error: " . mysqli_error($connector);
        exit;
    }
} else {
    echo "Failed to connect to the database.";
    exit;
}
?>

<div class="container-home">
    <div class="row">
        <div class="col-lg-6 contact-section"> <!-- Contact Us section -->
            <h3>Contact Us:</h3>
            <div class="social-icons">
                <?php foreach ($contactUs as $contact) { ?>
                    <a href="<?php echo $contact['url']; ?>" target="_blank" class="icon-links">
                        <img src="<?php echo $contact['icon']; ?>" alt="Contact" class="icons">
                        <span class="icon-text"><?php echo $contact['text']; ?></span>
                    </a>
                <?php } ?>
            </div>
        </div>
        <div class="col-lg-6 social-media"> <!-- Social Media section -->
            <h3>Social Media Platforms:</h3>
            <div class="social-icons">
                <?php foreach ($socialMedia as $social) { ?>
                    <a href="<?php echo $social['url']; ?>" target="_blank" class="icon-link">
                        <img src="<?php echo $social['icon']; ?>" alt="Social Media" class="icon">
                        <span class="icon-text"><?php echo $social['text']; ?></span>
                    </a>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

    <footer>
        <p>&copy; 2024 Zion Colors. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>