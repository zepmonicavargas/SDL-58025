<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="Logo.png">
    <title>Zion Colors | Admin Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Abril+Fatface|Poppins">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Spectral|Rubik">
    <style>
        body {
            font-family: Poppins, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #FDFD96, #F8C8DC); /* Yellow to Pink gradient */
        }
        header {
            background: linear-gradient(to right, #ff66a3, #CF9FFF); /* Fuchsia Pink to Purple gradient */
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            font-family: 'Abril Fatface', serif;
            margin: 0;
            color: #fff;
            font-size: 40px;
            letter-spacing: 2px;
        }
        nav {
            background-color: #ff66a3;
            padding: 10px 0;
            text-align: center;
        }
        nav ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }
        nav ul li {
            display: inline;
            margin: 0 10px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
        }
        nav ul li a.active {
            background-color: #fff;
            color: #ff66a3;
        }
        footer {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            background: linear-gradient(to right, #ff66a3, #CF9FFF);
            padding: 20px 0;
            text-align: center;
            color: #fff;
        }
        .card-header {
            background-color: #ff66a3;
            color: white;
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <h1>Zion Colors</h1>
    </header>
    <nav>
        <ul>
            <li><a>Admin Login</a></li>
        </ul>
    </nav>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Admin Login</div>
                    <div class="card-body">
                        <form id="userlogin">
                            <div class="form-group">
                                <label for="inputUsername">Username:</label>
                                <input type="email" class="form-control" id="inputUsername" name="inputUsername" placeholder="Enter Username" required>
                            </div>
                            <div class="form-group">
                                <label for="inputPassword">Password:</label>
                                <input type="password" class="form-control" id="inputPassword" name="inputPassword" placeholder="Enter Password" required>
                            </div>
                            <button type="button" class="btn btn-primary" id="btnlogin">Login</button>
                            <div id="warning" class="mt-3"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer>
        <p>&copy; 2024 Zion Colors. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
    $(document).ready(function() {
        var attempts = 0;
        var maxAttempts = 5;
        var countdown = null;
        var loginButton = $("#btnlogin"); // Select the login button

        function countdownTimer() {
            var seconds = 6; // Set the countdown duration
            countdown = setInterval(function() {
                seconds--;
                $('#warning').html('<div class="alert alert-warning" role="alert">Too many login attempts. Please try again after ' + seconds + ' seconds.</div>');
                if (seconds <= 0) {
                    clearInterval(countdown);
                    countdown = null; // Clear the countdown variable
                    $('#warning').html('');
                    $('#inputUsername').prop('disabled', false);
                    $('#inputPassword').prop('disabled', false);
                    loginButton.prop('disabled', false).removeClass('disabled'); // Re-enable the login button
                    attempts = 0;
                }
            }, 1000);
        }

        $("#btnlogin").click(function() {
            var username = $('#inputUsername').val();
            var password = $('#inputPassword').val();
            if (!username || !password) {
                $('#warning').html('<div class="alert alert-danger" role="alert">Both fields are required.</div>');
                return;
            }

            if (!loginButton.prop('disabled') && countdown === null) { // Check if the button is not disabled and countdown timer is not active
                // Disable the login button when clicked
                loginButton.prop('disabled', true).addClass('disabled'); // Add disabled class to make it unclickable
                $.post("modules/login_req.php", $("#userlogin").serialize(), function(loginResult) {
                    if (loginResult == "success") {
                        document.location = "./";
                    } else {
                        attempts++;
                        var remainingAttempts = maxAttempts - attempts;
                        if (attempts >= maxAttempts) {
                            $('#inputUsername').prop('disabled', true);
                            $('#inputPassword').prop('disabled', true);
                            loginButton.prop('disabled', true)
                            countdownTimer();
                        } else {
                            $('#warning').html('<div class="alert alert-danger" role="alert">' + loginResult + '. ' + remainingAttempts + ' attempts remaining.</div>');
                            loginButton.prop('disabled', false).removeClass('disabled'); // Re-enable the login button
                        }
                    }
                });
            }
        });
    });
</script>

</body>
</html>
