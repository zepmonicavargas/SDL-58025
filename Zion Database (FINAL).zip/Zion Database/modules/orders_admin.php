    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="Logo.png">
        <title>Zion Colors | Book Now</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Abril+Fatface|Poppins">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Spectral|Rubik">
        <style>
    body {
        font-family: Poppins, sans-serif;
        margin: 0;
        padding: 0;
        background: linear-gradient(to right, #FDFD96, #F8C8DC);
    }
    header {
        background: linear-gradient(to right, #ff66a3, #CF9FFF);
        padding: 20px 0;
        text-align: center;
    }
    /* Modal styling */
    
.modal {
    display: none;
    position: fixed;
    z-index: 1050;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
    outline: 0;
}
    /* Original Search Modal */
    #searchModal .modal-dialog {
        max-width: 1300px; /* Adjust the maximum width as needed */
        margin: 1.75rem auto;
        
    }

    /* Original Search Modal */
    #searchModal .modal-footer {
    position: absolute; /* Set position to absolute */
    bottom: 0; /* Align to the bottom of the modal */
    width: 100%; /* Ensure full width */
    padding: 20px; /* Add padding for spacing */
    background-color: #f8f9fa; /* Optional: Background color for modal footer */
}
#searchModal .modal-body {
    overflow-y: auto; /* Allow vertical scrolling */
    max-height: calc(100vh - 200px); /* Set maximum height for modal body */
}
#searchModal .modal-content {
    width: 100%; /* Ensure content fills the modal width */
    height: 80%; /* Adjust the height as needed */
}
.modal-dialog {
    max-width: 500px;
    margin: 1.75rem auto;
}
@media (min-width: 576px) {
    #searchModal.show .modal-body {
        max-height: calc(100vh - 300px); /* Adjust as needed */
    }
}
.modal-content {
    background-color: #fff;
    border: 1px solid #dee2e6;
    border-radius: 0.3rem;
    outline: 0;
}

.modal-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1rem;
    border-bottom: 1px solid #dee2e6;
}

.modal-title {
    margin-bottom: 0;
    line-height: 1.5;
}

.modal-body {
    position: relative;
    padding: 1rem;
}

.modal-footer {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding: 1rem;
    border-top: 1px solid #dee2e6;
}

.close {
    font-size: 1.5rem;
    font-weight: 700;
    line-height: 1;
    color: #000;
    text-shadow: none;
    opacity: 0.5;
    background-color: transparent;
    border: 0;
}

#searchResultsTableContainer {
    width: 90%;
    margin: 20px auto;
    padding: 20px;
}

#searchResultsTable {
    width: 100%;
    border-collapse: collapse;
}

#searchResultsTable th, #searchResultsTable td {
    border: 1px solid #ddd;
    padding: 8px;
    background-color: rgba(255, 255, 255, 0.8);
}

#searchResultsTable th {
    background-color: rgba(240, 240, 240, 0.8);
    text-align: center;
}

    header h1 {
        font-family: 'Abril Fatface', serif;
        margin: 0;
        color: #fff;
        font-size: 40px;
        letter-spacing: 2px;
    }
    nav {
        background-color: #ff66a3;
        padding: 10px 0;
        text-align: center;
    }
    nav ul {
        margin: 0;
        padding: 0;
        list-style: none;
    }
    nav ul li {
        display: inline;
        margin: 0 10px;
    }
    nav ul li a {
        color: #fff;
        text-decoration: none;
        font-size: 18px;
    }
    nav ul li a.active {
        background-color: #fff;
        color: #ff66a3;
        border-radius: 15px;
        padding: 5px;
    }
    footer {
        background: linear-gradient(to right, #ff66a3, #CF9FFF);
        padding: 20px 0;
        text-align: center;
        color: #fff;
    }
    .complete-btn, .delete-btn {
        width: 120px; /* Adjust the width as needed */
        margin: 5px; /* Add some margin for spacing */
    }
    .label-container {
        text-align: center;
    }
    .label {
        font-size: 1.5em;
        margin-bottom: 10px;
    }
    .container-booking {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        max-height: 600px;
    }
    h1 {
        text-align: center;
    }
    h2 {
        max-width: 900px;
        font-family: Spectral, serif;
        font-size: 40px;
        color: #ff66a3;
    }
    table {
        table-layout: fixed;
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        width: 14.28%; /* 100% divided by 7 days */
        height: 40px;  /* Adjust height as needed */
        border: 1px solid black;
        text-align: center;
        padding: 10px;
        box-sizing: border-box; /* Ensures padding does not affect the width/height */
    }
    th {
        background-color: #f0f0f0;
        text-align: center; /* Center the text in column labels */
    }
    td {
        vertical-align: middle; /* Centers the text vertically */
    }
    .button-container {
        text-align: center;
        margin-top: 20px;
        margin-bottom: 20px;
    }
    button {
        background-color: #87ceeb;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 25px;
        font-size: 16px;
        cursor: pointer;
    }
    button:hover {
        background-color: #005F6B;
    }
    .no-wrap {
        text-align: center;
        word-wrap: break-word;
    }
    .time-slots {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
    }
    .time-slot {
        margin: 5px;
    }
    .disabled {
        pointer-events: none;
        color: #aaa;
    }
    .selected-cell {
        background-color: #87ceeb;
        color: white;
    }
    .error-message {
        color: red;
        margin-top: 10px;
        text-align: center;
    }
    #reservationsTableContainer {
        width: 90%;
        margin: 20px auto;
        padding: 20px;
    }
    #reservationsTable {
        width: 100%;
        border-collapse: collapse;
    }
    #reservationsTable th, #reservationsTable td {
        border: 1px solid #ddd;
        padding: 8px;
        background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent background for cells */
    }
    #reservationsTable th {
        background-color: rgba(240, 240, 240, 0.8); /* Slightly different for headers */
        text-align: center; /* Center the text in column labels */
    }
    #selectedDateField {
        display: block;
        margin: 20px auto;
        padding: 10px;
        width: 100%;
        max-width: 300px;
        font-size: 16px;
        text-align: center;
        border: 1px solid #ddd;
        border-radius: 5px;
    }
    /* New CSS class for dates with reservations */
    .reserved-date {
        color: red; /* Change to your desired color */
    }
    /* Centering the text in the table headers */
    thead th {
        text-align: center;
    }
</style>

    </head>
    <body>
    <div class="container-booking">
        <h2><center>Active Reservations</center></h2><br>
        <center><a id="switchToCompleted" href="#">Switch to Completed Orders</a></center>
        <div class="button-container">
            <button id="prevButton">&#8249; Prev Month</button>
            <button id="nextButton">Next Month &#8250;</button>
        </div>
        <div class="label-container">
            <span class="label" id="monthLabel"></span>
        </div>
        <form method="POST" id="calendarForm">
            <input type="hidden" id="selectedDateInput" name="selected_date">
            <table id="calendar">
                <thead>
                    <tr>
                        <th>Sun</th>
                        <th>Mon</th>
                        <th>Tue</th>
                        <th>Wed</th>
                        <th>Thu</th>
                        <th>Fri</th>
                        <th>Sat</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Calendar rows will be dynamically added here -->
                </tbody>
            </table>
        </form>
        <input type="text" id="selectedDateField" placeholder="Selected date will appear here" readonly>
            <!-- Search Button -->
<div class="button-container">
    <button id="searchButton">Search Customer</button>
</div>
    </div><br><br>
    <div id="reservationsTableContainer"></div>


<!-- Original Search Modal -->
<div id="searchModal" class="modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Search Customer</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <input type="text" id="searchInput" class="form-control" placeholder="Enter customer name"><hr>
                <div id="searchResultsContainer"></div> <!-- Container for search results -->
            </div><br><br><br><br>
            <div class="modal-footer">
                <button type="button" id="searchSubmitButton" class="btn btn-primary">Search</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>




    <footer>
        <p>&copy; 2024 Zion Colors. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        const searchButton = document.getElementById('searchButton');
const searchModal = document.getElementById('searchModal');
const searchInput = document.getElementById('searchInput');
const searchSubmitButton = document.getElementById('searchSubmitButton');
const searchResultsTableContainer = document.getElementById('searchResultsTableContainer');

// Open modal when search button is clicked
searchButton.addEventListener('click', function() {
    $(searchModal).modal('show');
    selectedDateField.value = ''; // Restore the text field to its original state
    removeReservationsTable(); // Remove reservations table
});
// Handle search
searchSubmitButton.addEventListener('click', function() {
    const query = searchInput.value.trim();
    if (query) {
        fetchSearchResults(query);
    }
});

$(searchModal).on('hidden.bs.modal', function() {
    searchInput.value = ''; // Clear input field when modal is closed
    $('#searchResultsContainer').html(''); // Clear search results container
    selectedDateField.value = ''; // Restore the text field to its original state
    removeReservationsTable(); // Remove reservations table
});
function fetchSearchResults(query) {
    $.ajax({
        url: 'modules/search_customers.php', // Adjust the URL as needed
        type: 'POST',
        data: { query: query },
        success: function(response) {
            // Populate search results directly into the container
            $('#searchResultsContainer').html(response);
        },
        error: function(xhr, status, error) {
            console.error('Error fetching search results:', status, error);
        }
    });
}



// Utility function to handle closing the modal
$(searchModal).on('hidden.bs.modal', function() {
    searchInput.value = ''; // Clear input field when modal is closed
});

 const calendar = document.getElementById("calendar");
const prevButton = document.getElementById("prevButton");
const nextButton = document.getElementById("nextButton");
const monthLabel = document.getElementById("monthLabel");
const selectedDateInput = document.getElementById("selectedDateInput");
const selectedDateField = document.getElementById("selectedDateField");
const reservationsTableContainer = document.getElementById("reservationsTableContainer");
let currentMonth = 4; // May is month 4 (0-indexed)
let currentYear = 2024;
let selectedDateCell = null;

function updateCalendar() {
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const firstDay = new Date(currentYear, currentMonth, 1).getDay();
    let dayCounter = 1;
    let tbody = calendar.querySelector('tbody');
    tbody.innerHTML = "";

    monthLabel.textContent = `${months[currentMonth]} ${currentYear}`;

    // Fetch reservations for the current month
    fetchReservationsForMonth(currentYear, currentMonth + 1, function(reservedDates) {
        for (let row = 0; row < 6; row++) {
            let tr = document.createElement('tr');
            let isEmpty = true; // Flag to check if the row is empty

            for (let col = 0; col < 7; col++) {
                let td = document.createElement('td');
                if (row === 0 && col < firstDay) {
                    td.innerHTML = "";
                } else if (dayCounter > daysInMonth) {
                    td.innerHTML = "";
                } else {
                    const currentDay = dayCounter;
                    td.innerHTML = currentDay;
                    let cellDate = new Date(currentYear, currentMonth, currentDay);

                    // Adjust date to match calendar display
                    cellDate.setDate(cellDate.getDate() + 1); // Add one day to align with calendar display
                    let cellDateString = cellDate.toISOString().split('T')[0]; // Format date as YYYY-MM-DD

                    if (reservedDates.includes(cellDateString)) {
                        td.classList.add('reserved-date');
                    }

                    td.addEventListener('click', function() {
                        if (selectedDateCell) {
                            selectedDateCell.classList.remove('selected-cell');
                        }
                        selectedDateCell = td;
                        td.classList.add('selected-cell');
                        const selectedDate = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(currentDay).padStart(2, '0')}`;
                        selectedDateInput.value = selectedDate;
                        selectedDateField.value = selectedDate; // Update the text field
                        fetchReservations(selectedDate); // Fetch reservations for the selected date
                    });
                    dayCounter++;
                    isEmpty = false; // Row is not empty if there's a valid day
                }
                tr.appendChild(td);
            }
            tbody.appendChild(tr);
            
            if (isEmpty) {
                tbody.removeChild(tr); // Remove the row if it is empty
            }
        }
    });
}

function handleActionButtons() {
    document.querySelectorAll('.complete-btn').forEach(button => {
        button.addEventListener('click', function() {
            if (confirm('Are you sure you want to complete this reservation?')) {
                const row = this.closest('tr');
                const id = row.dataset.id;
                completeReservation(id, row);
            }
        });
    });

    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function() {
            if (confirm('Are you sure you want to delete this reservation?')) {
                const row = this.closest('tr');
                const id = row.dataset.id;
                deleteReservation(id, row);
            }
        });
    });
}

$(searchModal).on('hidden.bs.modal', function() {
    searchInput.value = ''; // Clear input field when modal is closed
    $('#searchResultsContainer').html(''); // Clear search results container
});

function completeReservation(id, row) {
    $.ajax({
        url: 'modules/complete_reservation.php',
        type: 'POST',
        data: { id: id },
        success: function(response) {
            if (response === 'success') {
                row.remove();
                checkAndRemoveReservedDate();
            } else {
                console.error('Error completing reservation:', response);
            }
        },
        error: function(xhr, status, error) {
            console.error('Error completing reservation:', status, error);
        }
    });
}

function deleteReservation(id, row) {
    $.ajax({
        url: 'modules/delete_reservation.php',
        type: 'POST',
        data: { id: id },
        success: function(response) {
            if (response === 'success') {
                row.remove();
                checkAndRemoveReservedDate();
            } else {
                console.error('Error deleting reservation:', response);
            }
        },
        error: function(xhr, status, error) {
            console.error('Error deleting reservation:', status, error);
        }
    });
}

function removeReservationsTable() {
    const reservationsTable = document.getElementById('reservationsTableContainer');
    reservationsTable.innerHTML = ''; // Remove the reservations table
}


// Handle Delete and Complete buttons in the search modal
document.getElementById('searchResultsContainer').addEventListener('click', function(event) {
    if (event.target.classList.contains('complete-btn')) {
        const row = event.target.closest('tr');
        const id = row.dataset.id;
        completeReservation(id, row);
    } else if (event.target.classList.contains('delete-btn')) {
        const row = event.target.closest('tr');
        const id = row.dataset.id;
        deleteReservation(id, row);
    }
});


function fetchReservations(date) {
    $.ajax({
        url: 'modules/fetch_reservations.php',
        type: 'POST',
        data: { selected_date: date },
        success: function(response) {
            reservationsTableContainer.innerHTML = response;
            highlightReservedDates();
            handleActionButtons(); // Bind action buttons events
            checkAndRemoveReservedDate();
        },
        error: function(xhr, status, error) {
            console.error('Error fetching reservations:', status, error);
        }
    });
}

function fetchReservationsForMonth(year, month, callback) {
    $.ajax({
        url: 'modules/fetch_reservations.php',
        type: 'POST',
        data: { year: year, month: month },
        success: function(response) {
            const reservedDates = JSON.parse(response);
            callback(reservedDates);
        },
        error: function(xhr, status, error) {
            console.error('Error fetching reservations:', status, error);
        }
    });
}

function highlightReservedDates() {
    const reservedDates = document.querySelectorAll('.reserved-date'); // Assuming this class is added dynamically by the PHP script
    reservedDates.forEach(function(td) {
        td.classList.add('reserved-date'); // Ensure the class is added even if it's already present
    });
}

function handleComplete(button) {
    var row = button.closest('tr');
    var id = row.getAttribute('data-id');
    
    // Perform the AJAX request to mark the reservation as complete (not implemented here)
    // After successful completion of the AJAX request, remove the row
    row.remove();
    
    checkTableEmpty();
}

function handleDelete(button) {
    var row = button.closest('tr');
    var id = row.getAttribute('data-id');
    
    // Perform the AJAX request to delete the reservation (not implemented here)
    // After successful completion of the AJAX request, remove the row
    row.remove();
    
    checkTableEmpty();
}

$(document).ready(function(){
            // Function to remove the "active" class from all links
            function removeActiveClass() {
                $("nav ul li a").removeClass("active");
            }

            // Click event handlers for navigation links
            $("#switchToCompleted").click(function(){
                removeActiveClass();
                $(this).addClass("active");
                document.location = "./?page=completed_admin";
            });
        })

function checkTableEmpty() {
    var table = document.getElementById('reservationsTable');
    var tbody = table.querySelector('tbody');
    if (!tbody || tbody.rows.length === 0) {
        table.remove();
        var container = document.getElementById('reservationMessageContainer');
        container.innerHTML = '<p>No reservations found for this date.</p>';
    }
}

// Handle Delete and Complete buttons in the search modal
document.getElementById('searchResultsContainer').addEventListener('click', function(event) {
    if (event.target.classList.contains('complete-btn')) {
        const row = event.target.closest('tr');
        const id = row.dataset.id;
        if (confirm('Are you sure you want to complete this reservation?')) {
            completeReservation(id, row);
        }
    } else if (event.target.classList.contains('delete-btn')) {
        const row = event.target.closest('tr');
        const id = row.dataset.id;
        if (confirm('Are you sure you want to delete this reservation?')) {
            deleteReservation(id, row);
        }
    }
});


function checkAndRemoveReservedDate() {
    const reservationsTable = document.querySelector('#reservationsTable tbody');
    if (!reservationsTable || reservationsTable.children.length === 0) {
        if (selectedDateCell) {
            selectedDateCell.classList.remove('reserved-date');
        }
    }
}

prevButton.addEventListener('click', function() {
    currentMonth--;
    if (currentMonth < 0) {
        currentMonth = 11;
        currentYear--;
    }
    updateCalendar();
});

nextButton.addEventListener('click', function() {
    currentMonth++;
    if (currentMonth > 11) {
        currentMonth = 0;
        currentYear++;
    }
    updateCalendar();
});

updateCalendar();

    </script>




    </body>
    </html>
