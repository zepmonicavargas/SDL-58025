<?php
if (isset($_POST['query'])) {
    $query = $_POST['query'];

    include 'db_connect.php';

    // Search query
    $stmt = $connector->prepare("SELECT id, name, date, time_slot, home_address, contact_no, email_address, completed_at FROM completed WHERE name LIKE ?");
    $likeQuery = '%' . $query . '%';
    $stmt->bind_param('s', $likeQuery);
    $stmt->execute();
    $result = $stmt->get_result();

    // Generate the HTML for the search results
    if ($result->num_rows > 0) {
        $html = '<table id="searchResultsTable" style="width:100%; border-collapse: collapse;">';
        $html .= '<thead><tr><th>Date</th><th>Time Slot</th><th>Name</th><th>Home Address</th><th>Contact No</th><th>Email Address</th><th>Completed At</th><th>Actions</th></tr></thead>';
        $html .= '<tbody>';
        while ($row = $result->fetch_assoc()) {
            $html .= '<tr data-id="' . $row['id'] . '">';
            $html .= '<td class="no-wrap">' . $row['date'] . '</td>';
            $html .= '<td class="no-wrap">' . $row['time_slot'] . '</td>';
            $html .= '<td class="no-wrap">' . $row['name'] . '</td>';
            $html .= '<td class="no-wrap">' . $row['home_address'] . '</td>';
            $html .= '<td class="no-wrap">' . $row['contact_no'] . '</td>';
            $html .= '<td class="no-wrap">' . $row['email_address'] . '</td>';
            $html .= '<td class="no-wrap">' . $row['completed_at'] . '</td>';
            $html .= '<td class="no-wrap">';
            $html .= '<button class="delete-btn">Delete</button>';
            $html .= '</td>';
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';
    } else {
        $html = '<p>No results found for "' . htmlspecialchars($query) . '".</p>';
    }

    echo $html;

    $stmt->close();
    $connector->close();
}
?>
