<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date = $_POST['txt_date'];
    $time_slot = $_POST['txt_time'];
    $name = $_POST['txt_name'];
    $home_address = $_POST['txt_home_address'];
    $contact_no = $_POST['txt_contact_no'];
    $email_address = $_POST['txt_email_address'];

    // Debugging: Check received values
    error_log("Received date: " . $date);
    error_log("Received time slot: " . $time_slot);
    error_log("Received name: " . $name);
    error_log("Received home address: " . $home_address);
    error_log("Received contact no: " . $contact_no);
    error_log("Received email address: " . $email_address);

    // Validate date format (assuming the date is in 'Y-m-d' format)
    $dateObj = DateTime::createFromFormat('Y-m-d', $date);
    if (!$dateObj) {
        echo "Invalid date format";
        exit();
    }

    // Convert date to 'Y-m-d' format for MySQL (although it should already be in this format)
    $formatted_date = $dateObj->format('Y-m-d');

    $stmt = $connector->prepare("INSERT INTO reservations (date, time_slot, name, home_address, contact_no, email_address) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $formatted_date, $time_slot, $name, $home_address, $contact_no, $email_address);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $connector->close();
}
?>
