<?php
// Include your database connection script
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get POST data
    $category = $_POST['category'];
    $url = $_POST['url'];
    $text = $_POST['text'];

    // Validate input data if necessary

    // Update the database
    $sql = "UPDATE socials SET url = ?, text = ? WHERE category = ?";
    if ($stmt = $connector->prepare($sql)) {
        // Bind parameters
        $stmt->bind_param("sss", $url, $text, $category);
        
        // Execute the statement
        if ($stmt->execute()) {
            // Send success response
            echo json_encode(['status' => 'success', 'message' => 'Update successful']);
        } else {
            // Send error response
            echo json_encode(['status' => 'error', 'message' => 'Update failed: ' . $stmt->error]);
        }
        
        // Close statement
        $stmt->close();
    } else {
        // Send error response
        echo json_encode(['status' => 'error', 'message' => 'Update failed: ' . $connector->error]);
    }
    
    // Close connection
    $connector->close();
} else {
    // Send error response for invalid request method
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}
?>
