<?php
include('db_connect.php'); // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['imageFile']) && $_FILES['imageFile']['error'] == UPLOAD_ERR_OK) {
        $uploadDir = 'carousel/'; // Directory to upload images
        $tmpName = $_FILES['imageFile']['tmp_name'];
        $fileExtension = pathinfo($_FILES['imageFile']['name'], PATHINFO_EXTENSION); // Get the file extension

        // Insert the file extension into the database
        $query = "INSERT INTO tbl_images (c_img) VALUES ('$fileExtension')";
        
        if (mysqli_query($connector, $query)) {
            $c_id = mysqli_insert_id($connector); // Get the last inserted id
            $newFileName = $c_id . '.' . $fileExtension; // Create the new file name
            $uploadFile = $uploadDir . $newFileName; // Full path to the new file

            // Move the uploaded file to the new location with the new name
            if (move_uploaded_file($tmpName, $uploadFile)) {
                echo "Image uploaded and database updated successfully.";
                header('Location: http://localhost/Zion%20Database/?page=homeadmin'); // Redirect with query parameter
                exit();
            } else {
                echo "File upload failed.";
            }
            
        } else {
            echo "Error: " . mysqli_error($connector);
        }
    } else {
        echo "No file uploaded or upload error.";
    }

    mysqli_close($connector); // Close the database connection
} else {
    echo "Invalid request method.";
}
?>

