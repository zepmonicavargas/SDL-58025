-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 23, 2024 at 06:13 PM
-- Server version: 8.2.0
-- PHP Version: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zion_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE IF NOT EXISTS `account` (
  `username` varchar(99) NOT NULL,
  `password` varchar(99) NOT NULL,
  `level_auth` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`username`, `password`, `level_auth`) VALUES
('zion', 'nails', 1);

-- --------------------------------------------------------

--
-- Table structure for table `completed`
--

DROP TABLE IF EXISTS `completed`;
CREATE TABLE IF NOT EXISTS `completed` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time_slot` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `home_address` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `contact_no` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `email_address` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `completed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `completed`
--

INSERT INTO `completed` (`id`, `date`, `time_slot`, `name`, `home_address`, `contact_no`, `email_address`, `completed_at`) VALUES
(1, '2024-05-30', '8PM - 11PM', 'ed', 'ddd', '3123', 'rabnea@gmail.com', '2024-05-23 03:10:38'),
(2, '2024-05-30', '4PM - 7PM', 'ed', 'ddd', '3123', 'edrian@920.com', '2024-05-23 03:10:39'),
(3, '2024-05-29', '8PM - 11PM', 'Edrianbiuojfbhashoih sahbosa dbvsa vkxz vnzxvnkxcvjkxlvkxcnklvxzlkvnvnzxvnlkv', 'ddd', '3123', 'rabnea@gmail.com', '2024-05-23 03:10:43'),
(4, '2024-05-29', '4PM - 7PM', 'ed', 'ddd', '3123', 'edrian@920.com', '2024-05-23 03:10:45'),
(5, '2024-05-31', '12PM - 3PM', 'ed', 'ddd', '3123', 'rabnea@gmail.com', '2024-05-23 03:10:49'),
(6, '2024-05-31', '4PM - 7PM', 'ed', 'ddd', '3123', 'rabnea@gmail.com', '2024-05-23 03:25:22'),
(7, '2024-05-27', '8PM - 11PM', 'ed', 'ddd', '3123', 'rabnea@gmail.com', '2024-05-23 03:27:57'),
(8, '2024-05-29', '4PM - 7PM', 'ed', 'ddd', '3123', 'edrian@920.com', '2024-05-23 03:32:25'),
(9, '2024-05-30', '12PM - 3PM', 'ed', 'ddd', '3123', 'edrian@920.com', '2024-05-23 07:29:09'),
(10, '2024-05-30', '4PM - 7PM', 'ed', 'ddd', '3123', 'rabnea@gmail.com', '2024-05-23 07:43:16'),
(11, '2024-05-24', '12PM - 3PM', 'ed', 'ddd', '3123', 'rabnea@gmail.com', '2024-05-23 07:54:22'),
(12, '2024-05-30', '4PM - 7PM', 'ed', 'ddd', '3123', 'rabnea@gmail.com', '2024-05-23 08:09:07'),
(13, '2024-05-30', '8PM - 11PM', 'ed', 'ddd', '3123', 'rabnea@gmail.com', '2024-05-23 08:19:50'),
(14, '2024-05-30', '8PM - 11PM', 'Edrian Rabena', 'adadsa', '12312123', 'edrianrabena07@gmail.com', '2024-05-23 10:15:54'),
(15, '2024-05-24', '12PM - 3PM', 'Edrian Rabena', 'adadsa', '12312123', 'edrianrabena07@gmail.com', '2024-05-23 10:15:55'),
(16, '2024-05-30', '4PM - 7PM', 'ed', 'ddd', '3123', 'rabnea@gmail.com', '2024-05-23 10:15:55'),
(17, '2024-05-29', '8PM - 11PM', 'ed', 'ddd', '3123', 'rabnea@gmail.com', '2024-05-23 10:17:18'),
(18, '2024-05-27', '4PM - 7PM', 'qdasd', 'adadsa', '12312123', 'edrianrabena07@gmail.com', '2024-05-23 10:17:37'),
(19, '2024-05-28', '8PM - 11PM', 'Edrian Rabena', 'adadsa', '12312123', 'edrianrabena07@gmail.com', '2024-05-23 10:18:04'),
(20, '2024-05-29', '8PM - 11PM', 'Edrian Rabena', 'adadsa', '12312123', 'edrianrabena07@gmail.com', '2024-05-23 10:19:10'),
(21, '2024-05-31', '8PM - 11PM', 'Edrian Rabena', 'adadsa', '12312123', 'edrianrabena07@gmail.com', '2024-05-23 10:27:06'),
(22, '2024-05-27', '8PM - 11PM', 'Edrian Rabena', 'adadsa', '12312123', 'edrianrabena07@gmail.com', '2024-05-23 11:44:57'),
(23, '2024-06-01', '12PM - 3PM', 'Edrian Rabena', 'adadsa', '12312123', 'edrianrabena07@gmail.com', '2024-05-23 11:45:47');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
CREATE TABLE IF NOT EXISTS `reservations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time_slot` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `home_address` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `contact_no` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `email_address` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `date`, `time_slot`, `name`, `home_address`, `contact_no`, `email_address`, `created_at`) VALUES
(59, '2024-05-27', '8PM - 11PM', 'ed', 'ermita', '3123', 'rabnea@gmail.com', '2024-05-23 17:52:37'),
(60, '2024-06-30', '4PM - 7PM', 'Edrian Rabena', 'adadsa', '12312123', 'edrianrabena07@gmail.com', '2024-05-23 17:56:13'),
(58, '2024-05-26', '8PM - 11PM', 'ed', 'ddd', '3123', 'rabnea@gmail.com', '2024-05-23 17:48:22'),
(55, '2024-05-27', '4PM - 7PM', 'Edrian Rabena', 'adadsa', '12312123', 'edrianrabena07@gmail.com', '2024-05-23 11:44:18');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `service_id` int NOT NULL AUTO_INCREMENT,
  `service_category` varchar(30) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `service_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `service_description` varchar(99) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `promo_percent` int NOT NULL,
  `orig_price1` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `orig_price2` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `image_url` varchar(99) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_category`, `service_name`, `service_description`, `promo_percent`, `orig_price1`, `orig_price2`, `image_url`) VALUES
(2, 'Soft Gel Nail Extensions', 'Plain Jelly Translucent ', 'Adds a subtle touch of color with a jelly-like finish.', 0, '1300', '1500', 'jpg'),
(3, 'Soft Gel Nail Extensions', 'Accent', 'Choose this option for a bold and eye-catching design.', 0, '1600', '1700', ''),
(4, 'Soft Gel Nail Extensions', 'Minimal', 'Ideal for those who prefer a simple and understated style.', 0, '1800', '2000', ''),
(5, 'Soft Gel Nail Extensions', 'Extra', 'Get creative with intricate designs and embellishments.', 0, '2100', '2300', ''),
(6, 'Soft Gel Nail Extensions', 'Advance Full Set', 'For the ultimate nail extension experience with advanced techniques.', 0, '2400', '2600', ''),
(7, 'Gel Overlay', 'Plain', 'A basic gel overlay to protect and strengthen your natural nails.', 0, '600', '', ''),
(8, 'Gel Overlay', 'Accent', 'Add a pop of color or design to your nails with this option.', 0, '700', '', ''),
(9, 'Gel Overlay', 'Minimal', 'Keep it simple yet stylish with a minimalistic gel overlay.', 0, '1000', '', ''),
(10, 'Gel Overlay', 'Extra', 'Upgrade to extra thickness for added durability and longevity.\r\n\r\n', 0, '1200', '', ''),
(11, 'Gel Overlay', 'Advance', 'Advanced gel overlay techniques for superior quality and performance.', 0, '1500', '', ''),
(12, 'Others', 'Gel Overlay Removal', 'Safely remove gel overlays without damaging your natural nails.', 0, '250', '', ''),
(13, 'Others', 'Nail Extension Removal', 'Professional removal of nail extensions to maintain nail health.', 0, '350', '', ''),
(14, 'Others', 'Press On Nails - Plain', 'Instantly transform your nails with easy-to-apply press-on nails in a plain finish.', 0, '350', '', ''),
(15, 'Others', 'Press On Nails - Minimal', 'Minimalistic press-on nails for a quick and chic nail makeover.', 0, '500', '', ''),
(16, 'Others', 'Press On Nails - Extra', 'Get extra length and durability with these press-on nails.', 0, '700', '', ''),
(44, 'Others', 'Press On Nails - Advance', 'Advanced press-on nails for a salon-quality look and feel.\r\n', 0, '1000', '', 'jpg'),
(51, 'Soft Gel Nail Extensions', 'Plain Solid Color', 'Perfect for those who prefer a classic and timeless look.', 0, '1000', '1200', 'jpg');

-- --------------------------------------------------------

--
-- Table structure for table `socials`
--

DROP TABLE IF EXISTS `socials`;
CREATE TABLE IF NOT EXISTS `socials` (
  `category` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `text` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `url` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `socials`
--

INSERT INTO `socials` (`category`, `text`, `url`) VALUES
('Contact Number', '0967 254 6106', '	 https://www.facebook.com/zioncolors.ph'),
('Email', 'zioncolors.ph@gmail.com', 'https://zioncolors.ph@gmail.com'),
('Address', 'JL Venue, Nagaroad, Las Piñas City', 'https://www.google.com/maps/dir/14.580332,120.9761'),
('Facebook', 'Zion Colors', '	 https://www.facebook.com/zioncolors.ph'),
('TikTok', '@zionbrnls_', 'https://www.tiktok.com/@zionbrnls_'),
('Instagram', '@zioncolors.ph', 'https://www.instagram.com/zioncolors.ph');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_images`
--

DROP TABLE IF EXISTS `tbl_images`;
CREATE TABLE IF NOT EXISTS `tbl_images` (
  `c_id` int NOT NULL AUTO_INCREMENT,
  `c_img` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_images`
--

INSERT INTO `tbl_images` (`c_id`, `c_img`) VALUES
(14, 'jpg'),
(13, 'jpg'),
(12, 'jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
